# Vitalos Relay — design reference

Unzip into `docs/relay/design/`. Each board is a standalone HTML file (open it in a browser; fonts load from Google Fonts) with a PNG render beside it. The build prompt (section 3) is the written spec; these files show the same thing visually. Logos in `assets/` are copies of the Vitalos design-system files: use the repo's own brand assets in production and never redraw them.

| Board | Size | Shows |
|---|---|---|
| Main | 1440×1040 | Name, launcher states, who-is-speaking colours, voice rules, tokens |
| Web-Welcome | 1440×900 | Desktop site with the 420px panel open, first visit |
| Panel-Answer | 420×900 | Visitor question, cited AI answer, feedback, streaming + stop |
| Panel-Handoff | 420×900 | Thumbs down, then the "Talk to a person" card |
| Panel-Live | 420×900 | Request sent, person joined, AI paused, live chat, typing |
| Mobile-Home | 390×844 | Mobile site with the compact launcher |
| Mobile-Chat | 390×844 | Full-screen sheet, low-confidence answer offering a person |
| Admin-Inbox | 1440×960 | Super admin Relay tab: list, thread, context panel |
| Admin-Alerts | 480×960 | Toast, bell menu, notification preferences |
| Email-Alert | 640×960 | Admin email alert with deep link |
| Admin-Knowledge | 1440×960 | Knowledge sources, entries, gaps, retrieval test |
| Flow | 1840×1040 | Request pipeline, hand-off steps, conversation statuses |

Sample names (Alex Morgan, Example Care Group, Jordan Ellis) are fictional.
